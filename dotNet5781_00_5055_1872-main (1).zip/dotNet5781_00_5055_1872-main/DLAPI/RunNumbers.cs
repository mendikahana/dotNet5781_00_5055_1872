﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace DO
{
    /// <summary>
    /// מחלקת מספרים רצים
    /// </summary>
    public static class RunNumbers
    {
        public static int BusLineID = 18;
    }
}
