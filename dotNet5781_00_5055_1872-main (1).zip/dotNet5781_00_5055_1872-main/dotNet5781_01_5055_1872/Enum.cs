﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
public enum Myenum { EnterNewBus = 1, BusSelection, RefuelingOrHandling, TravelPresentation, Exit = -1 };
