﻿using System;

partial class Class1
{
	//static partial void welcome 1872()
	//{ 

	//	Console.WriteLine(	" hi eliezer ");
	//}
}
