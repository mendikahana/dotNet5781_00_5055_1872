﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace DS
{
    /// <summary>
    /// 
    /// </summary>
    public class NumbersAreRunning
    {
        public static int LineInTravel = 0;
        public static int BusLineID = 0;
        public static int StationID = 0;
        public static int U_TravelID = 0;
    }
}
