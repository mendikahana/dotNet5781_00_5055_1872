﻿
/// <summary>
/// Options menu.
/// </summary>
public enum myenum { AddNewBus, AddStatian, DeleteBus, DeleteStatian, SearchLinesAtTheStation, SearchTimeTravelOptions, PrintOllBuses, PrintBusesAndStations, Exit = -1 };
